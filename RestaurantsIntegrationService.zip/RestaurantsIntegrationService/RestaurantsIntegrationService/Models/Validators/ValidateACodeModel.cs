﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RestaurantsIntegrationService.Models.Validators
{
    public class ValidateACodeModel
    {
        public string ACode { get; set; }
        public string ACY { get; set; }
    }
}